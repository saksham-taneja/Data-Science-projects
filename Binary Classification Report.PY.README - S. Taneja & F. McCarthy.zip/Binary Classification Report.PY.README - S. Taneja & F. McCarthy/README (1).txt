
README

Files submitted:

Jupyter Python File - Run the code to see our classification models and the classification evaluation scores for each models.
Classification Method Evaluation Report - Outlines our assignment method/results. 